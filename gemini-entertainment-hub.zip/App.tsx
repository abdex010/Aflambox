import React, { useState, useMemo, useEffect, useRef } from 'react';
import { ContentItem } from './types';
import { CONTENT_ITEMS } from './constants';
import Header from './components/Header';
import MovieGrid from './components/MovieGrid';
import MovieModal from './components/MovieModal';
import AiAssistantModal from './components/AiAssistantModal';

type FilterType = 'All' | 'Movie' | 'TV Series' | 'TV Program';

const App: React.FC = () => {
  const [contentItems] = useState<ContentItem[]>(CONTENT_ITEMS);
  const [selectedContentItem, setSelectedContentItem] = useState<ContentItem | null>(null);
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState<FilterType>('All');
  const [activeGenre, setActiveGenre] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const contentGridRef = useRef<HTMLHeadingElement>(null);
  const isInitialMount = useRef(true);

  useEffect(() => {
    if (isInitialMount.current) {
      isInitialMount.current = false;
    } else {
      contentGridRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [activeFilter, activeGenre, searchQuery]);

  const uniqueGenres = useMemo(() => {
    const allGenres = contentItems.flatMap(item => item.genre.split(', '));
    return ['All', ...Array.from(new Set(allGenres)).sort()];
  }, [contentItems]);

  const handleSelectContentItem = (item: ContentItem) => {
    setSelectedContentItem(item);
  };

  const handleCloseContentModal = () => {
    setSelectedContentItem(null);
  };

  const openAiModal = () => {
    setIsAiModalOpen(true);
  };

  const closeAiModal = () => {
    setIsAiModalOpen(false);
  };
  
  const handleAiSelection = (item: ContentItem) => {
    closeAiModal();
    setTimeout(() => {
        handleSelectContentItem(item);
    }, 300);
  };

  const filteredContent = contentItems.filter(item => {
    const matchesFilter = activeFilter === 'All' || item.type === activeFilter;
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGenre = activeGenre === 'All' || item.genre.split(', ').includes(activeGenre);
    return matchesFilter && matchesSearch && matchesGenre;
  });

  const filterButtons: {label: string, value: FilterType}[] = [
    { label: 'All', value: 'All' },
    { label: 'Movies', value: 'Movie' },
    { label: 'TV Series', value: 'TV Series' },
    { label: 'TV Programs', value: 'TV Program' },
  ];

  return (
    <div className="min-h-screen bg-gray-900 text-white font-sans">
      <Header 
        onOpenAiAssistant={openAiModal} 
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />
      <main className="p-4 sm:p-6 lg:p-8">
        <h1 ref={contentGridRef} className="text-3xl font-bold mb-6 text-gray-100">Featured Content</h1>
        
        <div className="mb-4 flex items-center justify-center flex-wrap gap-2 sm:gap-4">
          {filterButtons.map(({ label, value }) => (
            <button
              key={value}
              onClick={() => setActiveFilter(value)}
              className={`px-4 py-2 text-sm sm:text-base font-semibold rounded-full transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-indigo-500 ${
                activeFilter === value
                  ? 'bg-indigo-600 text-white shadow-lg'
                  : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
              }`}
              aria-pressed={activeFilter === value}
            >
              {label}
            </button>
          ))}
        </div>
        
        <div className="mb-8 border-t border-gray-800 pt-4 flex items-center justify-center flex-wrap gap-2 sm:gap-3">
          {uniqueGenres.map((genre) => (
            <button
              key={genre}
              onClick={() => setActiveGenre(genre)}
              className={`px-3 py-1.5 text-xs sm:text-sm font-semibold rounded-full transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-teal-500 ${
                activeGenre === genre
                  ? 'bg-teal-600 text-white shadow-md'
                  : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
              }`}
              aria-pressed={activeGenre === genre}
            >
              {genre}
            </button>
          ))}
        </div>

        <MovieGrid 
          movies={filteredContent} 
          onSelectMovie={handleSelectContentItem}
        />
      </main>

      {selectedContentItem && (
        <MovieModal movie={selectedContentItem} onClose={handleCloseContentModal} />
      )}

      {isAiModalOpen && (
        <AiAssistantModal 
          movies={contentItems} 
          onClose={closeAiModal} 
          onSelectMovie={handleAiSelection}
        />
      )}
    </div>
  );
};

export default App;