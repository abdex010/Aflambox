import React from 'react';
import { ContentItem } from '../types';
import { StarIcon } from './icons/StarIcon';

interface MovieCardProps {
  movie: ContentItem;
  onClick: () => void;
}

const MovieCard: React.FC<MovieCardProps> = ({ movie, onClick }) => {
  return (
    <div
      onClick={onClick}
      className="relative aspect-[2/3] w-full bg-gray-700 rounded-lg overflow-hidden shadow-lg cursor-pointer"
    >
      <img src={movie.posterUrl} alt={movie.title} className="w-full h-full object-cover" />
      
      <div className="absolute top-2 left-2">
        <span className="bg-black/70 text-white text-xs font-semibold px-2 py-1 rounded">
          {movie.quality}
        </span>
      </div>
      
      <div className="absolute top-2 right-2">
        <div className="bg-black/70 text-white text-xs font-semibold px-2 py-1 rounded flex items-center gap-1">
          <StarIcon className="w-3 h-3 text-yellow-400" isFilled={true} />
          <span>{movie.rating.toFixed(1)}</span>
        </div>
      </div>
    </div>
  );
};

export default MovieCard;