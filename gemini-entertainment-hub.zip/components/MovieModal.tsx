import React, { useState, useCallback, useEffect } from 'react';
import { ContentItem } from '../types';
import { generateSummary } from '../services/geminiService';
import { CloseIcon } from './icons/CloseIcon';
import { PlayIcon } from './icons/PlayIcon';
import { SparklesIcon } from './icons/SparklesIcon';
import { VolumeIcon } from './icons/VolumeIcon';
import { FullscreenIcon } from './icons/FullscreenIcon';

interface MovieModalProps {
  movie: ContentItem | null;
  onClose: () => void;
}

const MovieModal: React.FC<MovieModalProps> = ({ movie, onClose }) => {
  const [aiSummary, setAiSummary] = useState<string>('');
  const [isLoadingSummary, setIsLoadingSummary] = useState(false);
  const [isClosing, setIsClosing] = useState(false);

  const handleGenerateSummary = useCallback(async () => {
    if (!movie) return;
    setIsLoadingSummary(true);
    setAiSummary('');
    const summary = await generateSummary(movie.title, movie.description, movie.type);
    setAiSummary(summary);
    setIsLoadingSummary(false);
  }, [movie]);

  const handleClose = () => {
    setIsClosing(true);
    setTimeout(() => {
      onClose();
    }, 300); // Animation duration
  };
  
  // Reset closing state if the movie prop changes (e.g., another movie is selected while one is open)
  useEffect(() => {
    setIsClosing(false);
    setAiSummary('');
    setIsLoadingSummary(false);
  }, [movie]);


  if (!movie) return null;

  return (
    <div className={`fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center p-4 ${isClosing ? 'animate-fade-out' : 'animate-fade-in'}`}>
      <div className={`bg-gray-800 rounded-lg shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto relative ${isClosing ? 'animate-slide-down-scale' : 'animate-slide-up-scale'}`}>
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors z-10"
          aria-label="Close modal"
        >
          <CloseIcon className="w-6 h-6" />
        </button>

        <div className="grid md:grid-cols-3 gap-6 md:gap-8">
          <div className="md:col-span-1">
            <img src={movie.posterUrl} alt={movie.title} className="w-full h-auto object-cover rounded-l-lg" />
          </div>

          <div className="md:col-span-2 p-6 md:p-8">
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-2">{movie.title}</h2>
            <div className="flex items-center space-x-4 mb-4 text-gray-400">
              <span>{movie.year}</span>
              <span className="border-l border-gray-600 pl-4">{movie.genre}</span>
               <span className="border-l border-gray-600 pl-4 bg-gray-700 text-gray-300 px-2 py-0.5 rounded-md text-xs">{movie.type}</span>
            </div>
            
            <p className="text-gray-300 mb-6">{movie.description}</p>
            
            <h3 className="text-xl font-semibold text-white mb-3">Official Trailer</h3>
            <div className="relative aspect-video bg-black rounded-lg mb-6 overflow-hidden ring-1 ring-gray-700">
                {/* Main content: Play icon and placeholder text */}
                <div className="absolute inset-0 flex flex-col items-center justify-center text-white/50">
                    <PlayIcon className="w-16 h-16" />
                    <p className="mt-2 text-sm font-semibold">Trailer Not Available</p>
                </div>

                {/* Fake player controls overlay */}
                <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-black/60 to-transparent p-3">
                    {/* Fake progress bar */}
                    <div className="w-full h-1 bg-white/20 rounded-full">
                        <div className="w-1/4 h-full bg-indigo-500 rounded-full"></div>
                    </div>
                    {/* Fake controls */}
                    <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center gap-3">
                            <PlayIcon className="w-5 h-5 text-white" />
                            <VolumeIcon className="w-5 h-5 text-white" />
                            <span className="text-white text-xs font-mono">0:42 / 2:31</span>
                        </div>
                        <div>
                            <FullscreenIcon className="w-5 h-5 text-white" />
                        </div>
                    </div>
                </div>
            </div>
            
            <div className="bg-gray-900/50 p-4 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                    <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                        <SparklesIcon className="w-5 h-5 text-indigo-400"/>
                        AI Summary
                    </h3>
                    <button
                        onClick={handleGenerateSummary}
                        disabled={isLoadingSummary}
                        className="bg-indigo-600 text-white px-4 py-1.5 rounded-md text-sm font-semibold hover:bg-indigo-500 disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors"
                    >
                        {isLoadingSummary ? 'Generating...' : 'Regenerate'}
                    </button>
                </div>
                {isLoadingSummary && <p className="text-gray-400 italic">Gemini is thinking...</p>}
                {aiSummary && <p className="text-gray-300">{aiSummary}</p>}
                {!aiSummary && !isLoadingSummary && <p className="text-gray-500">Click "Regenerate" to get an AI-powered summary.</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieModal;